import axios from'axios';
import { id } from 'date-fns/locale';
import { DataContext } from '../components/Context';
// import Products from '../components/section/Products';

const PRODUCT_API_BASE_USER= 'http://localhost:8080/api/products/';

class ApiService{

    // static contextType = DataContext;


    // addProduct(id, title,prices,subtitle,descriptions,imagePic,type,count){
    //     return axios.post(PRODUCT_API_BASE_USER+"product",(
    //         id,
    //         title,
    //         prices,
    //         subtitle,
    //         descriptions,
    //         imagePic,
    //         type,
    //         count
    //     ))
    //     .then(response=>{
    //         console.log(response)
    //         localStorage.setItem("admin",JSON.stringify(response.data));
    //         return response.data;
    //     })
    // }

    fetchProduct(){
        return axios.get(PRODUCT_API_BASE_USER);
    }

    fetchProductById(id){
        return axios.get(PRODUCT_API_BASE_USER +id)
    }

    retriveProduct(product){
        return axios.post(PRODUCT_API_BASE_USER , product )
    }

    updateProduct(id){
        return axios.put(PRODUCT_API_BASE_USER +id)
    }

    deleteProduct(id){
        return axios.delete(PRODUCT_API_BASE_USER +id)
    }

    fetchProductByName(products){
        return axios.get(PRODUCT_API_BASE_USER + '?product='+products)
    }
    
    




}

export default new ApiService();