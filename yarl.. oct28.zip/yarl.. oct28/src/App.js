import React from 'react';
import Header from './components/Header'
import Section from './components/Section'
import {DataProvider} from './components/Context'
import Footer from './components/Footer';
import { BrowserRouter as Router } from 'react-router-dom';
// import { Router } from '@material-ui/icons';
// iport {BrowserRouter as Router} from 'react-'


class App extends React.Component{
  render(){
    return(
     
        <div >
           <DataProvider>
          <Header />
          <Router>
          <Section/>
          </Router>
          <Footer/>
          </DataProvider>
        </div>
      // </DataProvider>
    )
  }
}

export default App;
