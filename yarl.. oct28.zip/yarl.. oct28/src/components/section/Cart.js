import React, { Component } from 'react'
import {DataContext} from '../Context'
import {Link} from 'react-router-dom'
// import Colors from './Colors'
import '../css/Details.css'
import '../css/Cart.css'
// import inc from '../svg/incrs.png'
// import dec from '../svg/incrs2.png'
import { Grid } from '@material-ui/core'


export class Cart extends Component {

    static contextType = DataContext;

    componentDidMount(){
        this.context.getTotal();
    }

    
    
    render() {
        const {cart,increase,reduction,removeProduct,total} = this.context;
        if(cart.length === 0){
            
            
            return <h2 style={{textAlign:"center",marginTop:300,marginBottom:350}}><strong>Nothings Product</strong></h2>
            
        }else{
            return (
                <>
                <div className="tot" style={{backgroundImage:`url(${"https://image.freepik.com/free-photo/transition-blue-color_23-2147734218.jpg"})`,backgroundSize:"100%"}}>
                    {
                        cart.map(item =>(
                            <div className="details-cart" key={item.id}>
                                  <div className="delete" onClick={() => removeProduct(item.id)}>X</div>
                                  <Grid container>
                                      <Grid xs={4}>
                                <img src={item.image1} alt="erf" className="src"/>
                                </Grid>
                                <Grid xs={8}>
                                <div className="box">
                                    <div className="namehd">
                                        <h2>{item.product}</h2>
                                        </div><div>
                                        <p style={{color:"blue", fontSize:18}}>Rs {item.price * item.count} .00</p>
                                    </div>
                                    <div >
                                    {item.description}
                                    </div>
                                    <div className="amount" style={{paddingTop:30}}>
                                    {/* <img src={inc}> */}
                                        <button className="count"  onClick={() => reduction(item.id)}> - </button>
                                        {/* </img> */}
                                        <span>{item.count} Kg</span>
                                        {/* <img src={dec}> */}
                                        <button className="count" onClick={() => increase(item.id)}> + </button>
                                        {/* </img> */}
                                    </div>
                                </div>
                                </Grid>
                                </Grid>
                            </div>

                        ))
                    }
                    </div>
                    <div className="total">
                        <Link to="/payment">Payment</Link>
                        <h3>Total: Rs {total}.00</h3>
                    </div>
                
                </>
                )
            }
        }
}

export default Cart
