import React, { Component } from 'react'
import { Card, CardHeader, CardMedia, CardContent, IconButton, Typography, CardActions, Button, makeStyles,Avatar, Grid, Box, Badge, TextField, InputAdornment } from '@material-ui/core';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';
import {Link} from 'react-router-dom'
import {DataContext} from '../Context'
import '../css/Products.css'
import Basket from '../svg/basket.png'
import SearchIcon from '@material-ui/icons/Search';

import Star from '../svg/five_pointed_star.svg'
import Apiservice from '../../Services/Apiservice';
import axios from'axios';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import Pagination from '@material-ui/lab/Pagination';
import TablePagination from '@material-ui/core/TablePagination';
import { useTheme } from '@material-ui/core/styles';

  ///////////////////////////////////////////////////////////////


export class Products extends Component {
    constructor (){
        super();
        this.state={
            // quantity:1,
            products:[],
            currentPage: 1,
        productsPerPage: 10,
        searchString:"",
        searchChange:""
        };
        this.handleClick = this.handleClick.bind(this);

    }

    static contextType = DataContext;


    handleClick(event) {
      this.setState({
        currentPage: Number(event.target.id)
      });
    }

    searchChange = (e)=> {
        axios.get("http://localhost:8080/api/products?product="+e.target.value)
        .then ((response)=>{
            this.setState({products:response.data.data})
        }
            )
        this.setState({
            searchString:e.target.value
          })
}
    
    componentDidMount(){
       
        console.log("Helooooooo")

       
    }
   

    

    render() {

        const {products,addCart,cart,total,clickHandler} = this.context;
        const {  currentPage, productsPerPage } = this.state;

        const indexOfLastProduct = currentPage * productsPerPage;
        const indexOfFirstProduct= indexOfLastProduct- productsPerPage;
        const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);
  
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(products.length / productsPerPage); i++) {
          pageNumbers.push(i);
        }

        const renderPageNumbers = pageNumbers.map(number => {
          return (
            <li
              key={number}
              id={number}
              onClick={this.handleClick}
            >
              {number}
            </li>
          );
        });
        
        return (
            <>
            <div style={{marginTop:140,backgroundImage:`url(${"https://www.freepik.com/premium-photo/transition-blue-color_1530412.htm#page=1&query=blur&position=14"})`}}  >
               
                    <div>
                        <TextField label="Search the Product"
                         type="search"
                          variant="outlined"
                          value = {this.state.searchString}
                          onChange = {this.searchChange}
                          
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <IconButton onClick={()=> clickHandler(this.state.searchString)}  >
                                  <SearchIcon/>
                                </IconButton>
                              </InputAdornment>
                            )}}
                        //   value
                          style={{marginLeft:1470,marginBottom:20}}>

                          </TextField>

                    </div>
            <div className="icon" style={{position:"fixed"}}>
                {/* <span>{cart.length}</span> */}
                <strong>
                  <Badge badgeContent={cart.length}  anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }} overlap="circle" className="bas" >
                  <Link to="/cart">
                       <Button style={{width:60,paddingLeft:40}}> <img src={Basket} className="basket" /></Button>
                  </Link>
                 </Badge>
                 </strong>
            </div>
            <div  id="product" >
            {
                currentProducts.map((product,index) =>(
                    <div className="card" key={product.id}  >
                        <Box boxShadow={20}  >
                        <Card style={{backgroundColor:"#cfd8dc"}} >
                            <CardHeader 
                            action={
                                    
                                <IconButton aria-label="setting" style={{backgroundColor:"#9fa8da"}}  onClick={()=> addCart(product.id)} >
                                     <AddShoppingCartIcon />
                                </IconButton>
                            }
                            subheader={product.product}
                            />
                            <Link to={`/product/${product.id}`}>
                                <img src={product.image1} style={{height:250,width:400,marginLeft:4,borderRadius:10}}/>
                            </Link>
                            <CardContent  >
                                        <Typography varient="body2" component="tt" className="img">
                                           <strong style={{color:"#ff5722"}}> {product.category}</strong>
                                        </Typography>
                                    <br/>
                                        <Typography varient="h4" component="dp" >
                                        {/* <img src={Star} style={{width:40,height:40}}/> */}
                                           About it : <span style={{fontFamily:"fontFamily"}}>{product.description}</span> 
                                        </Typography><br/><br/>
                                       
                            </CardContent>
                            <CardActions>
                            <Grid container spacing={1}>
                                <Grid item xs={6}>
                                <Button size="small"  ><Link to={`/product/${product.id}`} className="txt">BUY</Link></Button>
                                </Grid>
                                <Grid item xs={6} style={{marginTop:18,color:"red"}} >
                                {/* <Button size="small" className={style.but} ><Link to="/payment"  className="txt">OFFER</Link></Button> */}
                                <Typography varient="body2" component="pc" >
                                    <h2><center>Rs.{product.price}</center></h2>
                                </Typography>
                                </Grid>
                                </Grid>
                            
                            </CardActions>

                        </Card>
                        </Box>
                        </div>
                )
             )
            }
       </div>
       <p>
       {renderPageNumbers}
       </p>
       </div>
       </>
        )
    }
}

export default Products



{/* <div id="product">
               {
                   products.map(product =>(
                       <div className="card" key={product._id}>
                           <Link to={`/product/${product._id}`}>
                               <img src={product.src} alt=""/>
                           </Link>
                           <div className="content">
                               <h3>
                                   <Link to={`/product/${product._id}`}>{product.title}</Link>
                               </h3>
                               <span>${product.price}</span>
                               <p>{product.description}</p>
                               <button onClick={()=> addCart(product._id)}>Add to cart</button>
                           </div>
                       </div>
                   ))
               }
            </div> */}
