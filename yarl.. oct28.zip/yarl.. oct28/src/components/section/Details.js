import React, { Component } from 'react'
import {DataContext} from '../Context'
import {Link} from 'react-router-dom'
import { Card, Typography, CardActions, Button, makeStyles,Avatar, Grid, Box, Badge, ButtonGroup ,TextField} from '@material-ui/core';
import { Slide } from 'react-slideshow-image';
import '../css/Details.css'
import Apiservice from '../../Services/Apiservice';


 const style={
        box:{
            margin:"auto",
            marginTop:500,
            width:1000,
            height:400,
            marginBottom:500
    
        },
        tot:{
            marginTop:500,
            margin:"auto",
            marginBottom:300,
            backgroundColor:"#fff8e1"
        },
        bad:{
            top:140,
            left:1650,
            position:"fixed"
        },
        cd:{
            // height:500,
            borderRadius:10,
        },
        imgs:{
         height:300,
         marginTop:0
         
        },
      slide:{
          height:300,
          paddingTop:0,
          marginTop:0
      },
      tit:{
          fontFamily:"fontFamily",
          padding:50,
          fontSize:30,
          textAlign:"center"
      },
    //   det:{
    //     margin
    //   },
      inline:{
          display:"inline"
      },
      prc:{
          fontSize:30,
          paddingLeft:50
      },
      stock:{
          color:"red",
          paddingLeft:50,
        //   textAlign:"right",
          paddingLeft:50
      },
      qua:{
        //   paddingLeft:50,
          paddingTop:40,
          textAlign:"center"
      },
      des:{
        //   paddingLeft:50,
          textAlign:"center",
          paddingTop:30,
    
      },
      ac:{
          backgroundColor:"black",
          color:"white",
          width:300,
          height:40,
          borderRadius:30
      },
      add:{
        paddingTop:30,
        // paddingLeft:50,
        textAlign:"center",
    
      },
      aq:{
          width:60,
          height:50
      }
    
    
    
    
    }

export class Details extends Component {
    static contextType = DataContext;
    state = {
        products: [],
        quantity:1
    }

    getProduct = () =>{
        if(this.props.match.params.id){
            const res = this.context.products;
            const data = res.filter(item =>{
                return item._id === this.props.match.params.id
            })
            this.setState({products: data})
        }
    };

    componentDidMount(){
        //this.getProduct();
        Apiservice.fetchProductById(this.props.match.params.id)
        .then((Response)=>{console.log(Response)
        
          this.setState({
            products:Response.data
          })
        })
    }

      qChange=(e)=>{
        this.setState({
            quantity:e.target.value
        })
    }



    render() {
        const {products} = this.state;
        const {addCart} = this.context;
        return (
            <>
                
                    
                        <div className="details" key={products._id} style={{backgroundImage:`url(${"https://www.freepik.com/free-photo/wooden-boards-with-shiny-background_973078.htm"})`,backgroundRepeat:"no-repeat"}}>
                             <Grid container style={{backgroundImage:`url(${"https://www.freepik.com/free-photo/wooden-boards-with-shiny-background_973078.htm"})`}}>
                <Grid xs={3}/>
                <Grid xs={6}  container style={{marginTop:200}}>
                    <Grid xs={7} >
                    <Card className={style.cd}>
                    <Slide className={style.slide} >
                            <div className={style.imagePic}>
                            {/* <span>1</span> */}
                            <img src ={products.image1}/>
                            </div>
                            <div className={style.imagePic}>
                            {/* <span>2</span> */}
                            <img src ={products.image1}/>
                            </div>
                            <div  className={style.imagePic}>
                            {/* <span>3</span> */}
                            <img src ={products.image1}/>
                            </div>
                            <div  className={style.imagePic}>
                            {/* <span>4</span> */}
                            <img src ={products.image1}/>
                            </div>
                            <div  className={style.imagePic}>
                            {/* <span>5</span> */}
                            <img src ={products.image1}/>
                            </div>
                     </Slide>
                     </Card>
                    </Grid>
                    <Grid xs={5} className={style.det} >
                        <Typography  className={style.tit} style={{marginLeft:50,marginTop:40,fontSize:20}}>
                           {/* <strong> {products.title}</strong> */}
                             <p>This type is <strong style={{color:"#0d47a1",}}>{products.type}</strong> and you get this item in edible prices </p>
                        </Typography>
                             <div className={style.inline} style={{marginLeft:50,marginTop:40}}>
                                 <div className={style.prc} >
                                      <strong>Price of 1kg :-  <span style={{color:"red"}}>Rs.{products.price}</span></strong><br/>
                                      <strong>Price of Your Pack :-  <span style={{color:"red"}}>Rs.{products.price * this.state.quantity}</span></strong><br/>

                                 </div>
                                 <p style={{color:"#757575",paddingLeft:50,marginTop:20}} >Local taxes included(where applicable)</p>
    
                                 <div className={style.stock}>
                                   <span style ={{color:"#ec407a"}}>{products.stock}low in stock</span>  
                                 </div>
                           </div> 
                           <TextField
                                            id="filled-number"
                                            label="kilogram"
                                            type="number"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            // defaultValue={1}
                                            variant="filled"
                                            value={this.state.quantity}
                                            onChange={this.qChange}
                                            style={{marginLeft:50}}
                                            />
                           <div className={style.add} >
                               <Link to="/cart" onClick={() => addCart(products.id)}>
                               <Button className={style.ac} style={{backgroundColor:"#212121",color:"white",marginLeft:50,marginTop:40,fontSize:18,width:150}}>Add To Card</Button>
                               </Link>
                               <Link to="/payment" onClick={() => addCart(products.id)}>
                               <Button className={style.ac} style={{backgroundColor:"#212121",color:"white",marginLeft:50,marginTop:40,fontSize:18,width:110}}>Buy</Button>
                               </Link>
                           </div>
                           <div className={style.qua} style={{marginLeft:50,marginTop:40}}>
                         <Typography >Quantity availabe for purchase now :{products.quantity}</Typography>
                           
                           </div>
                           {/* <div style={{paddingLeft:50,paddingTop:50}}><strong>Toatal: </strong> <span>Rs  {products.price * this.count}.00</span></div> */}
                           <div>
                           <Typography  className={style.des} style={{marginLeft:50,marginTop:40}}>
                                    {/* <p>## Description ##</p> */}
                                    {products.description}
                                </Typography>
                           </div>
    
                    </Grid>    
    
                               
                </Grid>
                <Grid xs={3}/>
            </Grid>
                        </div>
                    
                
            </>
        )
    }
}

export default Details

{/* <img src={item.imgPic} alt=""/>
<div className="box">
    <div className="row">
        <h2>{item.title}</h2>
        <span>${item.prices}</span>
    </div>
    {/* <Colors colors={item.colors}/> */}
//     <p>{item.descriptions}</p>
//     {/* <p>{item.content}</p> */}
//     <Link to="/cart" className="cart" onClick={() => addCart(item._id)}>
//         Add to cart
//     </Link>
// </div> */}


// {
//                 product.map(item=>(
//             <div style={{backgroundColor:"#fff8e1"}}>
//             <Badge color="secondary" badgeContent={cart.length} className={style.bad} >
//             <Link to="/cart"><img src="/icn2.png" /></Link>
//           </Badge>
//             <hr/>
//           <div className={style.tot}>
//           <hr/>
//             <Grid container>
//                 <Grid xs={3}/>
//                 <Grid xs={6}  container>
//                     <Grid xs={7} >
//                     <Card className={style.cd}>
//                     <Slide className={style.slide} >
//                             <div className={style.imagePic}>
//                             <span>1</span>
//                             {item.imagePic}
//                             <img src="/sf2.jpg" className={style.imgs}/>
//                             </div>
//                             <div className={style.imagePic}>
//                             <span>2</span>
//                             {item.im2}
//                             <img src="/sf2.jpg" className={style.imgs}/>
//                             </div>
//                             <div  className={style.imagePic}>
//                             <span>3</span>
//                             {item.im3}
//                             <img src="/sf2.jpg" className={style.imgs}/>
//                             </div>
//                             <div  className={style.imagePic}>
//                             <span>4</span>
//                             {item.im4}
//                             <img src="/sf2.jpg" className={style.imgs}/>
//                             </div>
//                             <div  className={style.imagePic}>
//                             <span>5</span>
//                             {item.im5}
//                             <img src="/sf2.jpg" className={style.imgs}/>
//                             </div>
//                      </Slide>
//                      </Card>
//                     </Grid>
//                     <Grid xs={5} className={style.det}>
//                         <Typography  className={style.tit}>
//                            <strong> {item.title}</strong>
//                              <p>This type is {item.type} and you get this item from {item.place}</p>
//                         </Typography>
//                              <div className={style.inline}>
//                                  <div className={style.prc}>
//                                       <strong>{item.prices}Rs 3563.00</strong><br/>
//                                  </div>
//                                  <p style={{color:"#757575",paddingLeft:50}}>Local taxes included(where applicable)</p>
    
//                                  <div className={style.stock}>
//                                      {item.stock}now on sale/sold/low in stock
//                                  </div>
//                            </div> 
//                            <div className={style.add}>
//                                <Link to="/cart" onClick={() => addCart(item._id)}>
//                                <Button className={style.ac}>Add To Card</Button>
//                                </Link>
//                            </div>
//                            <div className={style.qua}>
//                                <Typography >Quantity</Typography>
//                             <ButtonGroup>
//                                 <Button
//                                     style={{height:50,width:125}}
//                                     aria-label="reduce"
//                                     onClick={() => {
//                                     this.setCount(Math.max(this.count - 1, 0));
//                                     }}
//                                 >
//                                     <img src="/icn4.png" fontSize="small"  />
//                                 </Button>
//                                <TextField className={style.aq} variant="filled" size="small" value={this.count} placeholder="Kg"></TextField>
//                                 <Button
//                                     style={{height:50,width:125}}
//                                     aria-label="increase"
//                                     onClick={() => {
//                                     this.setCount(this.count + 1);
//                                     }}
//                                 >
//                                     <img src="/icn5.png" fontSize="small" />
//                                 </Button>
//                             </ButtonGroup>
//                            </div>
//                            <div style={{paddingLeft:50,paddingTop:50}}><strong>Toatal: </strong> <span>Rs  {item.prices} * {this.count}.00</span></div>
//                            <div>
//                            <Typography  className={style.des}>
//                                     <p>## Description ##</p>
//                                     {item.description}dhsehsert
//                                 </Typography>
//                            </div>
    
//                     </Grid>    
    
                               
//                 </Grid>
//                 <Grid xs={3}/>
//             </Grid>
//             <hr/>
//             </div>
    
//             </div>
//             // <hr/>
               
//                 ))
//              }    



// gabdabbb
 {/* <ButtonGroup>
                                <Button
                                    style={{height:50,width:125}}
                                    aria-label="reduce"
                                    onClick={() => {
                                    this.setCount(Math.max(this.count - 1, 0));
                                    }}
                                >
                                    <img src="/icn4.png" fontSize="small"  />
                                </Button>
                               <TextField className={style.aq} variant="filled" size="small" value={this.count} placeholder="Kg"></TextField>
                                <Button
                                    style={{height:50,width:125}}
                                    aria-label="increase"
                                    onClick={() => {
                                    this.setCount(this.count + 1);
                                    }}
                                >
                                    <img src="/icn5.png" fontSize="small" />
                                </Button>
                            </ButtonGroup> */}