import React from "react";
import StripeCheckout from "react-stripe-checkout";
import axios from "axios";
import Carticn from '../svg/YLogo.png';



const StripeButton = ({ price }) => {
  const publishableKey = "pk_test_51HUFVPIfJ6z5pQk5vIVhsEZ1Y5Na3Hsc1zl3Asvd81gp36ez5gizmHhZioAoTqXxRKm9p7r9fvO4k9FoD21VnbFh00Mi1lFu5T";
  const stripePrice = price * 100;
  // pk_test_51HEBecGDUUednvESGXzGZzkC20nJfRlPqe2gsBucEpxKvFsFT3hcOQ6wYJCZIJ2aCtz820NgME5hHRnftfXN594300NxwE1hn2
  const onToken = (token) => {
    console.log(token);
    axios
      .post("http://localhost:8080/api/auth/payment", {
        amount: stripePrice,
        token,
      })
      .then((response) => {
        console.log(response);
        alert("payment success");
      })
      .catch((error) => {
        console.log(error);
        alert("Payment failed");
      });
  };

  return (
    <StripeCheckout
      amount={stripePrice}
      label="Pay Now"
      name="YarlMakket"
      image={Carticn}
      description={`Export And Delivery Dryseafood`}
      panelLabel="Pay Now"
      token={onToken}
      stripeKey={publishableKey}
      currency="LKR"
    />
  );
};

export default StripeButton;