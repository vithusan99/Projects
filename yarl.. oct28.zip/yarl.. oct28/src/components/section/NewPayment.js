import React from "react";
// import React, {Component} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
// import img from '.././images/chooseprb.jpg';

// import "./Checkout.styles.scss";
import StripeButton from "./Stripebutton.js";
import { OutlinedInput } from '@material-ui/core';
import { DataContext } from '../Context';
;
// import "/home/sinthujan/Desktop/StripePayment-master/frontend/src/components/Stripe.css";

const useStyles = makeStyles({
  root: {
    width:400,
  },
  media: {
    height: 200,
  },
});



export  class  Newpayment extends React.Component  {

    constructor(){
        super();
        this.state={
            // products:[],
            // total:""
        }

    }
    static contextType = DataContext;

    render(){
        const {total,products}=this.context;

  return (
    <>
    <div className="checkout" style={{marginLeft:500,marginTop:300,marginBottom:300}}>
    {/* { */}
      {/* products.map((item)=>( */}
    <Card style={{width:500}}>
      <CardActionArea>
        <CardMedia>
        {products.image1}
        </CardMedia>
         {/* style={{backgroundImage:`url(${img})`,backgroundRepeat:"no-repeat",height:"30vh",width:"100%",backgroundSize:"cover"}} */}
        
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
            Your Price
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p">
        ${total}
          {/* <OutlinedInput
            label="price"
            id="price"
            type="number"
            placeholder="price"
            required
            autoComplete="price"
            value={state.price}
            onChange={(e) => {
              setState({...state, price: e.target.value});
            }} */}
          {/* /> */}
          </Typography>
        </CardContent>
      </CardActionArea>
      <CardActions>
        <Button size="small" color="primary">
        <StripeButton price={total}/>
        </Button>
       
      </CardActions>
    </Card>
      {/* )) */}
          {/* } */}

     
 
    
      
    </div>
 </>
  
  );
        }
};

// export default Checkout;

//   const classes = useStyles();
//   const [state, setState] = useState({
//     price: '',
  
    
//   });