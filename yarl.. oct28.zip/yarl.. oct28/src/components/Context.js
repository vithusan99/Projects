import axios from 'axios';
import React, { Component } from 'react'
import Apiservice from '../Services/Apiservice';

export const DataContext = React.createContext();

export class DataProvider extends Component {
    constructor(){
        super()
    this.state = {
        products: [] ,
        cart: [],
        total: 0
    }
}

    addCart = (id) =>{
        const {products, cart} = this.state;
        const check = cart.every(item =>{
            return item.id !== id
        })
        if(check){
            const data = products.filter(product =>{
                return product.id === id
            })
            this.setState({cart: [...cart,...data]})
        }else{
            alert("The product has been added to cart.")
        }
    };

    reduction = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            
            if(item.id === id){
                console.log(id)
                item.count === 0.5 ? item.count = 0.5 : item.count -=0.5;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    increase = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item.id === id){
                item.count += 0.5;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    removeProduct = id =>{
        if(window.confirm("Do you want to delete this product?")){
            const {cart} = this.state;
            cart.forEach((item, index) =>{
                if(item.id === id){
                    cart.splice(index, 1)
                }
            })
            this.setState({cart: cart});
            this.getTotal();
        }
       
    };

    getTotal = ()=>{
        const{cart} = this.state;
        const res = cart.reduce((prev, item) => {
            return prev + (item.price * item.count);
        },0)
        this.setState({total: res})
    };
    
    componentDidUpdate(){
        localStorage.setItem('dataCart', JSON.stringify(this.state.cart))
        localStorage.setItem('dataTotal', JSON.stringify(this.state.total))
    };

    componentDidMount(){
        const dataCart = JSON.parse(localStorage.getItem('dataCart'));
        if(dataCart !== null){
            this.setState({cart: dataCart});
        }
        const dataTotal = JSON.parse(localStorage.getItem('dataTotal'));
        if(dataTotal !== null){
            this.setState({total: dataTotal});
        }

        // ourProd=()=>{
        Apiservice.fetchProduct()
        .then((response)=>{
            console.log(response)
            this.setState({
               products:response.data
            })
        }
        )
    // }


    }

    clickHandler=(search)=>{
        axios.get("http://localhost:8080/api/products?product="+search)
        .then ((response)=>{
            this.setState({products:response.data})
        }
            )
        
    }

   

    render() {
        const {products, cart,total} = this.state;
        const {addCart,reduction,increase,removeProduct,getTotal,clickHandler,ourProd} = this;
        return (
            <DataContext.Provider 
            value={{products, addCart, cart, reduction,increase,removeProduct,total,getTotal,clickHandler,ourProd}}>
                {this.props.children}
            </DataContext.Provider>
        )
    }
}






 //             { "_id":"21",
            //     "title":"Cape Mackeral",
            //     "prices":"Rs 1600.00 ",
            //     "subtitle":"Linna/Saman Para",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":'https://ranathungadryfish.lk/images/products/17.jpg',
            //     "type":"Mackeral",
            //     "count": 1,
                
        
            // },
            // {
            //     "_id":"22",
            //     "title":"Sansuru",
            //     "prices":"Rs 900.00 ",
            //     "subtitle":"Thalapath",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://ranathungadryfish.lk/images/products/17.jpg",
            //     "type":"Sinamon",
            //     "count": 1
        
            // },
            // {
            //     "_id":"23",
            //     "title":"Magra ",
            //     "prices":"Rs 900.00",
            //     "subtitle":"Kirimorra",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/dried-fish-black-background-plastic-bag-92861524.jpg",
            //     "type":"Sinamon",
            //     "count": 1
        
            // },
            // {
            //     "_id":"24",
            //     "title":"Soodai",
            //     "prices":"Rs 2000.00 ",
            //     "subtitle":"Soodai",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/dried-fish-market-labuan-bajo-flores-island-indonesia-photo-taken-there-many-kind-sold-here-97519784.jpg",
            //     "type":"Small fish",
            //     "count":1
        
            // },
            // {
            //     "_id":"25",
            //     "title":"Netholi",
            //     "prices":"Rs 2000.00 ",
            //     "subtitle":"Netholi",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/dried-fish-market-labuan-bajo-flores-island-indonesia-photo-taken-there-many-kind-sold-here-97519929.jpg",
            //     "type":"x-Small fish",
            //     "count": 1
        
            // },
            // {
            //     "_id":"26",
            //     "title":"Smoked fish",
            //     "prices":"Rs 2000.00 ",
            //     "subtitle":"Cure",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/smoked-fish-to-heat-small-private-smokehouse-hangers-full-trout-33017838.jpg",
            //     "type":"Smoked",
            //     "count": 1
        
            // },
            // {
            //     "_id":"27",
            //     "title":"Thirijaparai",
            //     "prices":"Rs 2000.00 ",
            //     "subtitle":"Kadda",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/dried-fish-hanging-roof-shops-jaffna-north-sri-lanka-forms-major-part-lankan-diets-79199695.jpg",
            //     "type":"Paarai",
            //     "count": 1
        
            // },
            // {
            //     "_id":"28",
            //     "title":"Karallo",
            //     "prices":"Rs 2000.00 ",
            //     "subtitle":"Kaaral",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/dried-fish-sale-roadside-market-kratie-province-cambodia-51213119.jpg",
            //     "type":"Small fish",
            //     "count": 1,
        
            // },
            // {
            //     "_id":"29",
            //     "title":"Thondan",
            //     "prices":"Rs 200.00 ",
            //     "subtitle":"Small soodai",
            //     "descriptions":
            //     "That give you a good strong to body. You can buy this with any quantity.  ",
            //     "imagePic":"https://thumbs.dreamstime.com/b/dried-sea-fish-to-preserve-food-sale-140225736.jpg",
            //     "type":"Small fish",
            //     "count": 1
        
            // },