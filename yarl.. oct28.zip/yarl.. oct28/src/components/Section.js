import React, { Component } from 'react'
import Products from './section/Products'
import Details from './section/Details'
import {Route} from "react-router-dom"
import Cart from './section/Cart'
import Mate from './Mate'
import PriceList from './Pricelist'
import Header from './Header'
// import { Feedback, Router } from '@material-ui/icons'
// import Employees from './Addproducts'
import Popup from './Popups'
import Addproduct from './Addproduct'
import Payments from './Payment'
import OrderDetails from './History'
// import ContactUs from './ContactUs'
import Contactus from './Contactus'
import Productprice from './NewPrices'
import Feedback from './FeedBack'
import { Newpayment } from './section/NewPayment'
// import Newpayment from './section/NewPayment'
// import { Feedback } from '@material-ui/icons'



export class Section extends Component {
    render() {
        return (
            <section>
                <Route exact path={["/","/home"]} component={Mate} />
                <Route exact path="/product" component={Products}  />
                <Route exact path="/product/:id" component={Details} />
                <Route path="/cart" component={Cart} />
                <Route path="/payment" component={Newpayment} />
                <Route path="/prices" component={Productprice}/>
                <Route exact path="/QD0tTak3Ap6r1" component={Addproduct} />
                <Route exact path="/QD0tTak3Ap6r1/addnew" component={Popup} />
                <Route exact path="/QD0tTak3Ap6r1/addnew/:id" component={Popup} />
                <Route exact path="/QD0tTak3Ap6r1/history" component={OrderDetails} />
                <Route exact path="/contact" component={Contactus} />
                <Route exact path="/QD0tTak3Ap6r1/feedback" component={Feedback} />


            </section>
        )
    }
}

export default Section
// NewComponent