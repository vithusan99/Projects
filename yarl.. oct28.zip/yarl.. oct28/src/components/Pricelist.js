// import React, { Component }  from 'react';
// import {  makeStyles, Box } from '@material-ui/core';
// import { blue, red } from '@material-ui/core/colors';
// import { TabOutlined, CenterFocusStrong, FormatItalic, Style } from '@material-ui/icons';
// import ReactTable from 'react-table-6';
// import 'react-table-6/react-table.css'
// import { DataContext } from './Context';
// import Apiservice from '../Services/Apiservice';


// const style2= makeStyles({
// //   
//  tot:{

// 	boxShadow:20,

//  },
//  bac:{
// 	//  backgroundColor:"#fff8e1",
// 	 width:"100%",
// 	 height:"100%"
//  },
//  table:{
// 	 backgroundColor:"",
// 	 backgroundRepeat: 'no-repeat',
// 	 backgroundImage: `url(${"https://media.cntraveller.in/wp-content/uploads/2018/10/Secret-Sri-Lanka-Jaffna-fort-1.jpg"})`, 
// 	 backgroundBlendMode : 'multiply',
//  },
//  pap:{
// 	 width:"70%",
// 	 marginTop:175,
// 	marginLeft:350,
// 	// boxAlign:"center"
// 	boxShadow:20,
// 	marginBottom:200,
// 	backgroundColor:"#fff8e1"
//  }
   
    
// })



// function  PriceList() {
// 	// constructor(){
// 	// 	super();
// 	// 	this.state={
// 	// 		products:[]
// 	//    };

// 	// }

// 	// static contextType = DataContext;

// // 	componentDidMount(){

// //         Apiservice.fetchProduct()
// //             .then((Response)=>{
// //             console.log("HI")
// //             this.setState( {
// //                 products:Response.data
// //             })
// //       })
    

  
// //   }

	
// 	// render(){
//   const  style1 = style2();
// 	const data=[{
	
// no:'01',
// name:"Katta (thirijaaparai) (no.1) -1kg",
// prc:"Rs. 1600.00"
// },
// {
// no:'02',
// name:"Katta (02) -1kg",
// prc:"Rs. 1400.00"
// },
// {
// no:'03',
// name:"Netholi -1kg",
// prc:"Rs. 900.00"
// },

// {
// no:'04',
// name:"Maasi dryfish - 1kg",
// prc:"Rs. 1800.00"
// },
// {
// no:'05',
// name:"kanavaai(Cuttlefish) (No.1) 1kg",
// prc:"Rs. 4500.00"
// },
// {
// no:'06',
// name:"kanavaai(Cuttlefish) (02) 1kg",
// prc:"Rs. 900.00"
// },
// {
// no:'07',
// name:"Iraal(Shrimp) (No.1)  1kg",
// prc:"Rs. 3600.00"
// },
// {
//     no:'08',
//     name:"Iraal(Shrimp) (02)  1kg",
//     prc:"Rs. 2600.00"
//     },
// {
// no:'09',
// name:"Keramin nets",
// prc:"Rs. 315.00"
// },

// {
// no:'10',
// name:"Little Kiramin",
// prc:"Rs. 240.00"
// },
// {
// no:'11',
// name:"keeramin03",
// prc:"Rs. 220.00"
// },
// {
// no:'12',
// name:"Fire para",
// prc:"Rs. 180.00"
// },
// {
// no:'13',
// name:"Karunkanni Paarai -1kg",
// prc:"Rs. 4000.00"
// },
// {
// no:'14',
// name:"Kooral -1kg",
// prc:"Rs. 3500.00"
// },
// {
// no:'15',
// name:"Mural-1kg",
// prc:"Rs. 1400.00"
// },
// {
// no:'16',
// name:"Panna -1kg",
// prc:"Rs. 600.00"
// },
// {
// no:'17',
// name:"Keramine 02 1kg",
// prc:"Rs. 1000.00"
// },

// {
// no:'18',
// name:"keeramin03",
// prc:"Rs. 220.00"
// },
// {
// no:'17',
// name:"Fire para 02",
// prc:"Rs. 150.00"
// },
// {
// no:'18',
// name:"Kadal Koli 01 -1kg",
// prc:"Rs. 1400.00"
// },
// {
// no:'19',
// name:"Kadal Koli 02 -1kg",
// prc:"Rs. 1000.00"
// },
// {
// no:'20',
// name:"Karol -1kg",
// prc:"Rs. 150.00"
// },
// {
// no:'21',
// name:"Parai 1kg",
// prc:"Rs. 1200.00"
// },
// {
// no:'22',
// name:"Sinna Panna 1kg",
// prc:"Rs. 300.00"
// },
//     ]
	
	

// const columns=[{
// 		Header:"No.",
// 		accessor:'no',

// },
// {
// 		Header:"Product Name",
// 		accessor:'name',

// },
// {
// 	Header:"Prices",
// 	accessor:'prc',

// }
// ]

//     return(
// 		<>
// 		<div className={style1.bac}>
// 		<Box className={style1.pap} boxShadow={20}>
// 			<ReactTable data={data} columns={columns} defaultPageSize={15} pageSizeOptions={[5,10,15]} className={style1.table}/>
// 		</Box>
// 		</div>
// 		</>

//     )
// // }constructor(){
// 	// 	super();
// 	// 	this.state={
// 	// 		products:[]
// 	//    };

// 	// }
// }
// export default PriceList



// // no:'01',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'02',
// // name:"Wanna - Lanka",
// // prc:"Rs. 400.00"
// // },
// // {
// // no:'03',
// // name:"Thalapath Male '01' 1kg",
// // prc:"Rs. 1700.00"
// // },

// // {
// // no:'04',
// // name:"Ankles - 1kg",
// // prc:"Rs. 1200.00"
// // },
// // {
// // no:'05',
// // name:"Cooney 1kg",
// // prc:"Rs. 750.00"
// // },
// // {
// // no:'06',
// // name:"Issa",
// // prc:"Rs. 1200.00"
// // },
// // {
// // no:'07',
// // name:"Keramin nets",
// // prc:"Rs. 315.00"
// // },

// // {
// // no:'08',
// // name:"Little Kiramin",
// // prc:"Rs. 240.00"
// // },
// // {
// // no:'09',
// // name:"keeramin03",
// // prc:"Rs. 220.00"
// // },
// // {
// // no:'10',
// // name:"Fire para",
// // prc:"Rs. 180.00"
// // },
// // {
// // no:'11',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'12',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'13',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'14',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'15',
// // name:"Keramine 02 1kg",
// // prc:"Rs. 1000.00"
// // },

// // {
// // no:'16',
// // name:"keeramin03",
// // prc:"Rs. 220.00"
// // },
// // {
// // no:'17',
// // name:"Fire para",
// // prc:"Rs. 180.00"
// // },
// // {
// // no:'18',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'19',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'20',
// // name:"Katta Lanka -1kg",
// // prc:"Rs. 1400.00"
// // },
// // {
// // no:'21',
// // name:"Power - Lanka 1kg",
// // prc:"Rs. 900.00"
// // },
// // {
// // no:'22',
// // name:"Keramine 02 1kg",
// // prc:"Rs. 1000.00"
// // },
