import { Box, Button, Grid, Icon, IconButton, InputAdornment, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from '@material-ui/core';
import React, {Component} from 'react';
import SearchIcon from '@material-ui/icons/Search';
import { Link } from 'react-router-dom';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import ClearIcon from '@material-ui/icons/Clear';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import Apiservice from '../Services/Apiservice';
import { DataContext } from './Context';
import Popup from './Popups';
import Axios from 'axios';




const style={
    search:{
        // marginTop:40,
        // marginLeft:60,
    }
}
export default class Productprice extends Component{
    constructor(){
        super();
        this.state={
             products:[],
             currentPage: 1,
             productsPerPage: 7
        };
        this.handleClick = this.handleClick.bind(this);

    }

    handleClick(event) {
        this.setState({
          currentPage: Number(event.target.id)
        });
      }

    componentDidMount(){

        Apiservice.fetchProduct()
            .then((Response)=>{
            console.log("HI")
            this.setState( {
                products:Response.data
            })
      })
    }  

//      searchChange = (e) => {
//         Axios.get("http://localhost:8081/shipping/searchedPages")
// console.log(e.target.value)
// setSearchString(e.target.value)
// }

   
    render(){
        // const { count, page, rowsPerPage, onChangePage } = this.props;
        const {products,setProducts}=this.state
        // const {products,addCart,cart,total} = this.context;
        const {  currentPage, productsPerPage } = this.state;

        const indexOfLastProduct = currentPage * productsPerPage;
        const indexOfFirstProduct= indexOfLastProduct- productsPerPage;
        const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);
  
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(products.length / productsPerPage); i++) {
          pageNumbers.push(i);
        }

        const renderPageNumbers = pageNumbers.map(number => {
            return (
              // <Grid container>
              // <Grid xs={2}/>
              //   <Grid container xs={8}>
              <button
                key={number}
                id={number}
                onClick={this.handleClick}
                // style={{}}
              >
               
                  {number}
              </button>
              // </Grid >
              // <Grid xs={2}/></Grid>
            );
          });



        return(
            <div style={{backgroundImage:`url(${"https://as2.ftcdn.net/jpg/01/00/50/09/500_F_100500991_OEQ25cvW2MWip3za3zSM3V1UHAIPQBIf.jpg"})`, backgroundRepeat:"no-repeat",backgroundSize:"cover",}}>
            <Grid container style={{}} >
                <Grid xs={2}/>
                <Grid xs={8}>
                    <Box boxShadow={3}  m={1} p={2} style={{width:1100,height:"69%",marginTop:150}} >
                    <Paper style={{marginTop:5,marginBottom:100}}>
      

         <div style={style.search} style={{color:"white"}}>
                                    <TextField
                            id="input-with-icon-textfield"
                            label="Search"
                            type="search"
                            // onChange={searchChange}
                            InputProps={{
                                startAdornment: (
                                  <InputAdornment position="start">
                                    <IconButton >
                                      <SearchIcon/>
                                    </IconButton>
                                  </InputAdornment>
                                )
                            }}
                            
                        />
                       
             </div>

             <TableContainer style={{ boxShadow:90}}>
                 <Table style={{minWidth:150}}>
                         <TableHead style={{backgroundColor:"#1a237e", }}>
                         <TableRow style={{color:"white"}}>
                            <TableCell align="left"><b></b></TableCell>
                            {/* <TableCell align="left" style={{width:200,color:"white"}}><b>ID</b></TableCell> */}
                            <TableCell align="left" style={{color:"white"}}><b>Product Name</b></TableCell>
                            <TableCell align="left" style={{color:"white"}}><b>Price</b></TableCell>
                            <TableCell align="left" style={{color:"white"}}><b>Available Quantity</b></TableCell>
                         
                         </TableRow>
                         </TableHead> 
                         <TableBody>
                             {/* {console.log(products)} */}
                         {currentProducts.map((row) => (
                                <TableRow>
                                
                                <TableCell>
                                </TableCell>
                                <TableCell align="left">{row.product}</TableCell>
                                <TableCell align="left">{row.price}</TableCell>
                                <TableCell align="left">{row.quantity}</TableCell>
                                </TableRow>
                            ))}
                             </TableBody>  
                              <TableFooter>
                              {renderPageNumbers}

                              {/* <div style={{display:"inline"}}>{renderPageNumbers}</div> */}

                                 {/* <TablePagination
                                //  rowsPerPageOptions={5}
                                //  // colSpan={3}
                                //  count={count}
                                //  rowsPerPage={rowsPerPage}
                                //  page={page}
                                 
                                //  onChangePage={handleChangePage}
                                //  onChangeRowsPerPage={handleChangeRowsPerPage}
                                //  ActionsComponent={renderPageNumbers}
                               >
                                 {renderPageNumbers}

                                 </TablePagination> */}
                             </TableFooter> 
                 </Table>

             </TableContainer>
                            </Paper>
                            {/* <div style={{display:"inline"}}>{renderPageNumbers}</div> */}
                            </Box>
                            </Grid>
                            <Grid xs={2}/>
                            </Grid>
        
        </div>
        )
    }
} 