import React from 'react';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import MenuBookOutlinedIcon from '@material-ui/icons/MenuBookOutlined';
import HighQualityIcon from '@material-ui/icons/HighQuality';
import EmojiPeopleIcon from '@material-ui/icons/EmojiPeople';
import DirectionsBusIcon from '@material-ui/icons/DirectionsBus';



function WhyUs(){
    return(
        <>
            <h1 align = "left">Why should you Buy Dry Fish using YarlMakket?</h1>
            <p align = "left">
                We pride ourselves in being the platform that helps to the consumers to buy the 
                high quality dry fish to their doorstep, Our Advantage:
            </p>
            <Grid container spacing={1} >
                <Grid item xs = {4} sm = {4} style={{padding:40}}>
                    <Card style={{height:250}} variant="outlined">
                        <center><HighQualityIcon style={{ fontSize: 72 }}/></center>
                        <h3 align = "left" style={{margin:20}}>High Quality</h3>
                        <p align = "justify" style={{margin:20}}>
                            With one simple search you can buy various types of High Quality Dry Fish through our website,
                            
                        </p>
                    </Card>
                </Grid>
                <Grid item xs = {4} sm = {4} style={{padding:40}}>
                    <Card style={{height:250}} variant="outlined">
                        <center><DirectionsBusIcon style={{ fontSize: 72 }}/></center>
                        <h3 align = "left" style={{margin:20}}>Safest tool with delivery system</h3>
                        <p align = "justify" style={{margin:20}}>
                            After your order we have ensure each and every packet that deliverd by us
                            even though our suppliers are the local peoples we always check each and every packet
                        </p>
                    </Card>
                </Grid>
                <Grid item xs = {4} sm = {4} style={{padding:40}}>
                    <Card style={{height:250}} variant="outlined">
                        <center><EmojiPeopleIcon style={{ fontSize: 72 }}/></center>
                        <h3 align = "left" style={{margin:20}}>More Customer Focused</h3>
                        <p align = "justify" style={{margin:20}}>
                           Yes! We consider the customer more than anything else, We are quick response for the
                           oders as well as sending answers for your questions 
                        </p>
                    </Card>
                </Grid>
            </Grid>
        </>
    )
}
export default WhyUs
