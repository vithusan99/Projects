import React from 'react';
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'
import { makeStyles, Grid,Paper,Box} from '@material-ui/core';
// import { Autorenew } from '@material-ui/icons';
import slide1 from './svg/pexels-chait-goli-2031992.jpg'
 
const keepStyle=makeStyles({
    cont:{
        marginTop:87,
        margin:-9
    },
    im1:{
      // backgroundImage:`url(${'/AOCF.webp'})`,
      backgroundRepeat: 'no-repeat',
    },
    
    slide:{
      width:"100%",
      // height:300
    },
    tot:{

    },
    pap:{
      
      
      backgroundColor:"white",
      borderRadius:60,
      width:1250,
      // height:250,
      margin:25,
      
  },
  sub:{
      color:"red",
      fontFamily:"Arial"
  },
  box:{
    // marginLeft:200,
    // marginTop:200,
    // padding:25,
    textAlign:"center",
    backgroundColor:"#ffcc80",
    borderRadius:60,
    width:1300,
    height:800,
    // marginLeft:300,
    // marginTop:80

  },
  des:{
    // margin:'auto'
  }
})

 
const Slideshow = () => {

    const style=keepStyle();

    return (
      <div className={style.cont}  >
        {/* <Grid container spacing={0}> */}
          {/* <Grid xs={12} > */}
        <Slide className={style.slide} >
          <div className={style.tot}>
            <div className={style.im1}>
              {/* <span>1</span> */}
              <img src='https://images.unsplash.com/photo-1591410448119-1b49cbb3b83e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80' style={{width:"100%",height:800}}/>
            </div>
          </div>
          <div className={style.tot}>
            <div className={style.im1}>
              {/* <span>2</span> */}
              <img src='https://niwadudeals.lk/uploads/images/hotels/slider/733076_2.jpg' style={{width:"100%",height:800}}/>
            </div>
          </div>
          <div className={style.tot}>
            <div  className={style.im1}>
              {/* <span>3</span> */}
              <img src={slide1} style={{width:"100%",height:800}}/>
            </div>
          </div>
          <div className={style.tot}>
            <div  className={style.im1}>
              {/* <span>4</span> */}
              <img src='https://media.istockphoto.com/photos/map-of-sri-lanka-picture-id503227456' style={{width:"100%",height:800}}/>
            </div>
          </div>
          <div className={style.tot}>
            <div  className={style.im1}>
              {/* <span>5</span> */}
              <img src='https://images.unsplash.com/photo-1552055569-d54ae89a11b7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80' style={{width:"100%",height:800}}/>
            </div>
          </div>
        </Slide>
        {/* </Grid> */}
        {/* </Grid> */}
        {/* <Grid xs={12} container>
          <Grid xs={2}/>
        <Grid xs={8} className={style.des}>
          <Box boxShadow={3}
            bgcolor="background.paper"
            m={0}
            p={0}
           className={style.box}>
        <Paper className={style.pap}>
                <div className={style.cont}>
                    <div className={style.sub}>
                        <h2>add a attractive intro</h2>
                    </div>
                </div>
            </Paper>
            </Box>
        </Grid>
        <Grid xs={2}/>
        </Grid> */}
      </div>
    )
}
export default Slideshow

// style={{'backgroundImage': `url(${slideImages[2]})`}
// https://media.gettyimages.com/photos/sunset-on-a-tropical-island-thailand-picture-id618591472?k=6&m=618591472&s=612x612&w=0&h=HP8G32O5zygo4OEJFsN3Qu0LVeTrl3UVZSz6lsfHMIg=