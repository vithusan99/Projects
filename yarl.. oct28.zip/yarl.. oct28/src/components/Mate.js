import React from 'react';
import {Button, Box, makeStyles, AppBar,Toolbar, div, Grid, Card, Paper } from '@material-ui/core';
import Slideshow from './Slide';
import { red } from '@material-ui/core/colors';
// import Star from './svg/five_pointed_star.svg'
// import Background from 'https://www.shutterstock.com/image-photo/abstract-blur-image-road-night-time-791096059';
import './Mate.css'       
// import DepartureBoardIcon from '@material-ui/icons/DepartureBoard';
// import SearchOutlinedIcon from '@material-ui/icons/SearchOutlined';
// import VerifiedUserOutlinedIcon from '@material-ui/icons/VerifiedUserOutlined';
import '../index.css'
// import Mainpic from './svg/Mainpic.jpg'
import Customer from './svg/Customer_focused.png'
import Delivery from './svg/Delivery.png'
import Highquality from './svg/High_Quality.png'
// import Fish from './svg/fish.png'

const mateStyle= makeStyles({

    slide:{
        marginTop:50,
        // height: 100
        
    },

    hero: {
      background: "linear-gradient(135deg, #0079bf, black)",
    },

  
      root:{
          flexGrow:1,
          marginTop:50
        //   backgroundImage:`url(${Background})`
      },
      reet:{

        
      },
      pap:{
          margin:40,
          textAlign:"center",
          paddingTop:20,
          backgroundColor:"#ffecb3"

      },
      des:{
        //   paddingTop:30
      },
      pap1:{
        marginTop:120,
        marginLeft:40,
        marginRight:40,
        textAlign:"center",
        paddingTop:20,
        backgroundColor:"#ffecb3"
      },
      star:{
        width:50,
        height:50
      },
      cont:{
          fontFamily:"Apple Color Emoji",
      }

      

})


 function Mate(){

    const style=mateStyle();

        return  (
            <>
                  <div className="whole">   
                    <Slideshow className={style.slide}/>

                    {/* <div id="hero"> 
                     <div class="containedback" > 
                       <div class="row align-items-center text-center text-md-left"> 
                         <div class="col-lg-6">
                           <h1>Get higher quality supplies of dried fish .</h1>
                           <p class="lead">From trusted suppliers.</p> 
                          </div> 
                         <div class="col-lg-6"> 
                          <img src={Mainpic} width="582" class="img-fluid" alt="" /> 
                        </div> 
                        <form class="quick-signup pt-5" method="POST" action="/signup_redirect"> 
                        <input name="email" class="quick-signup-email" type="email" placeholder="Email"> 
                        <button type="submit" data-analytics-button="greenSignupHeroButton" class="btn btn-wrap btn-success btn-lg px-4">Sign Up – It’s Free!</button> 
                        </form> 
                        </div> 
                        </div> 
                     </div> */}
                  </div>

                            {/* <div id="fish">
                            <h2>QUALITY </h2>
                            <div>
                              <img src={Fish} style={{fontSize: 75, marginTop:50}} />
                            </div>

                            </div> */}
                  
                   
            
            <div className="reet" style={{ textAlign:"center", marginTop:150, fontFamily:"", fontSize:20 }}>

            <h1>Welcome to YarlMakket</h1>
            <p>The place you choose to buy high quality dry fishes on the market.<br/>
            We got our supplies from trusted karainagar suppliers.<br/>
            Start shopping...</p>
              </div>

              <div id="wrapper_home"  >
                <div class="overlay">
                <h2>Best high quality dried fish In Jaffna</h2>
                  <h3>Products made for your satisfaction. Contact us Now : +94 123 456 789</h3>
                  <a class="btn-slide" href="tel:+94 123 456 789 ">CALL NOW</a>
                  </div>
              </div>
            <div className={style.root}>
            <Grid container direction="row">
                    <Grid xs={2}/>
            <Grid  xs={8} className={style.des}>
                <Grid container spacing={0}>
                    <Grid xs={4}>
                        <Paper className={style.pap1} elevation={5}  style={{width:150},{height:300}}>
                            <div className={style.cont}>                             
                            <h2>FAST DELIVERY</h2>
                            <div >
                            </div>                             
                             <img src="http://www.pngmart.com/files/7/Delivery-PNG-Image.png" style={{width:200, marginTop:50}}/>
                            </div>


                        </Paper>
                        </Grid>
                        <Grid xs={4}>
                        <Paper className={style.pap} elevation={15} style={{width:250},{height:400}}>
                            <div className={style.cont}>
                            <h2>MORE CUSTOMER-FOCUSED SERVICES</h2>
                            <div >
                              <img src="https://www.thebusybeehives.com/wp-content/uploads/2015/02/CustomerFocused1.png" style={{width:"100%",height:300, marginTop:45}} />
                            </div>
                            </div>
                        </Paper>
                        </Grid>
                        <Grid xs={4}>
                        <Paper className={style.pap1} elevation={5} style={{width:150},{height:300}}>
                            
                            <div className={style.cont}>
                            <h2>QUALITY </h2>
                            <div>
                              <img src="http://clipart-library.com/images_k/medal-transparent/medal-transparent-3.png" style={{width:160,height:180, marginTop:60}} />
                            </div>

                            </div>
                        </Paper>
                        </Grid>
            </Grid>
            </Grid>
            <Grid xs={2} />
            </Grid>
            </div>
        </>
        )
    
}

export default Mate



////////////////////////////////////////////////
// import React from 'react';
// import {Button, Box, makeStyles, AppBar,Toolbar, div, Grid, Card, Paper } from '@material-ui/core';
// import Slideshow from './Slide';
// import { red } from '@material-ui/core/colors';
// import Star from './svg/five_pointed_star.svg'
// // import Background from 'https://www.shutterstock.com/image-photo/abstract-blur-image-road-night-time-791096059';
//   import './Mate.css' ;       
// import WhyUs from './WhyUs';


// const mateStyle= makeStyles({
//     slide:{
//         marginTop:50,
//         // height:00
        
//     },

  
//       root:{
//           flexGrow:1,
//         //   backgroundImage:`url(${Background})`
//       },
//       reet:{
//         flexGrow:1,
//         position:"absolute",
//         marginLeft:900,
//         textAlign:"right",
//         top:-150
        
//       },
//       pap:{
//           margin:40,
//           textAlign:"center",
//           paddingTop:20,
//           backgroundColor:"#ffecb3"

//       },
//       des:{
//         //   paddingTop:30
//       },
//       pap1:{
//         marginTop:120,
//         marginLeft:40,
//         marginRight:40,
//         textAlign:"center",
//         paddingTop:20,
//         backgroundColor:"#ffecb3"
//       },
//       star:{
//         width:50,
//         height:50
//       },
//       cont:{
//           fontFamily:"Apple Color Emoji",
//       }

      

// })


//  function Mate(){

//     const style=mateStyle();

//         return  (
//             <>
//                   <div>   
//             <Slideshow className={style.slide}/>
//             </div>
//             <WhyUs/>
           
//             <div className={style.root}>
//             <Grid container direction="row">
//                     <Grid xs={2}/>
//             <Grid  xs={8} className={style.des}>
//                 <Grid container spacing={0}>
//                     <Grid xs={4}>
//                         <Paper className={style.pap1} elevation={5}  style={{width:150},{height:300}}>
//                             <div className={style.cont}>
//                             <h2>FAST DELIVERY</h2>
//                             <div >
//                             <img src={Star} className={style.star}/>
//                             <img src={Star}  className={style.star}/>
//                             <img src={Star}  className={style.star}/>
//                             </div>
//                             </div>
//                         </Paper>
//                         </Grid>
//                         <Grid xs={4}>
//                         <Paper className={style.pap} elevation={15} style={{width:250},{height:400}}>
//                             <div className={style.cont}>
//                             <h2>MORE CUSTOMER-FOCUSED SERVICES</h2>
//                             <div >
//                             <img src={Star}  className={style.star}/>
//                             <img src={Star}  className={style.star}/>
//                             <img src={Star}  className={style.star}/>
//                             </div>
//                             </div>
//                         </Paper>
//                         </Grid>
//                         <Grid xs={4}>
//                         <Paper className={style.pap1} elevation={5} style={{width:150},{height:300}}>
//                             <div className={style.cont}>
//                             <h2>QUALITY </h2>
//                             <div >
//                             <img src={Star}  className={style.star}/>
//                             <img src={Star}  className={style.star}/>
//                             <img src={Star}  className={style.star}/>
//                             </div>
//                             </div>
//                         </Paper>
//                         </Grid>
//             </Grid>
//             </Grid>
//             <Grid xs={2} />
//             </Grid>
//             </div>
//         </>
//         )
    
// }

// export default Mate


 {/* <div className="tri" >
            <div className={style.reet}> */}
            {/* <Grid xs={12} container>
          <Grid xs={2}/> */}
        {/* <Grid xs={8} className={style.des}>
          <Box boxShadow={3}
            bgcolor="background.paper"
            m={0}
            p={0}
           className={style.box}>
        <Paper className={style.pap}>
                <div className={style.cont}>
                    <div className={style.sub}> */}
                        {/* <h2>add a attractive intro</h2>
                        <p>wrugawiefhawekfjvakwehbwaehbarhvgr<br/>
                        erjtngwkrjgnkw3jrngkwj5rgnwkjrngnrgk3rg<br/>
                        jghqbwregfqwuergfqu3y4gtfoqu324ygfql3rhdfsthrthnrtndhtgndthynetynetymney5jnetyjneytjnetyh<br/>
                        waejrghq3ureygqo34uiygfqr3gbljewrh<br/>
                        arekgjerhbgqo34uyq3uto4ygtq3uy4gtkjerhbfesf<br/>
                        imsocoolguy soleavemealone bczurfire<br/>
                        wergsretjhnsrthsethsethsethse</p> */}
                    {/* </div>
                </div>
            </Paper>
            </Box>
        </Grid> */}
        {/* <Grid xs={2}/>
        </Grid> */}
            {/* </div>
            </div> */}