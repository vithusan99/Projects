import React from "react";
import ReactDOM from "react-dom";
import StripeCheckout from "react-stripe-checkout";
import axios from "axios";
import { toast } from "react-toastify";
import Cart from "./section/Cart";
import { Grid } from "@material-ui/core";
import { DataContext } from "./Context";

import "react-toastify/dist/ReactToastify.css";
// import "./styles.css";

toast.configure();




function Payments() {
  const [products] = React.useState({});

  // const contextType = DataContext;
  // const {products}=this.contextType;

  async function handleToken(token, addresses) {
    const response = await axios.post("", { token, products });
    const { status } = response.data;

    console.log("Response:", response.data);
    if (status === "success") {
      toast("Success! Check email for details", { type: "success" });
    } else {
      toast("Something went wrong", { type: "error" });
    }
  }


  // axios.delete('http://localhost:8080/feedback/' + deleteId)
  // .then((Response)=>{
  //   setMesseage('Feedback Deleted Successfully')
  //   setTimeout(()=>fillAlert(),3000)
  // })
  


  return (


    // <div style={{backgroundImage:`url(${"https://www.freepik.com/premium-photo/white-desk-front-blur-dinning-table-against-wall_3133636.htm#page=1&query=blur&position=40"})`, backgroundRepeat:"no-repeat",backgroundSize:"100%">
    <div className="container" style={{marginTop:350,marginLeft:850,marginBottom:280}}>
      <div className="product">
        <h3>On Sale  ${products.price}</h3>
      </div>
      <StripeCheckout
        stripeKey="pk_test_51HUFVPIfJ6z5pQk5vIVhsEZ1Y5Na3Hsc1zl3Asvd81gp36ez5gizmHhZioAoTqXxRKm9p7r9fvO4k9FoD21VnbFh00Mi1lFu5T"
        token={handleToken}
        amount={products.price * 100}
        name="YarlMakket"
        billingAddress
        shippingAddress
      />
    </div>
  
  );
}

export default Payments;

// class OrderList extends React.Component{
//   constructor(){
//       super();
      
//   }

//   static contextType = DataContext;

//   render(){

//     const cart=this.context

//     return(
//       <>
//       {
//         cart.map(item =>(
//           <div>
//           <Grid container>
//             <Grid xs={3}/>
//             <Grid xs={3}>
//               {item.product}
//             </Grid>
//             <Grid xs={3}>
//               {item.price}
//             </Grid>
//             <Grid xs={3}/>
//           </Grid>
//           </div>
//         ))
//       }
//       </>
//     )
//   }
// }

// export default OrderList

/////////////////////////////////////////////////////////////

// import React, { Component } from 'react'

// export class Payments extends Component {

//     static contextType = DataContext;

//     render() {
//         const cart=this.context
//         return (
//             <div>
//                 <h2 style={{textAlign: "center"}}>Payment Component</h2>
//       {
//         cart.map(item =>(
//           <div>
//           <Grid container>
//             <Grid xs={3}/>
//             <Grid xs={3}>
//               {item.product}
//             </Grid>
//             <Grid xs={3}>
//               {item.price}
//             </Grid>
//             <Grid xs={3}/>
//           </Grid>
//           </div>
//         ))
//       }


//             </div>
//         )
//     }
// }

// export default Payments

