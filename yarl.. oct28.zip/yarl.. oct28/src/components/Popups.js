
import { Button, Grid, Paper, Snackbar, TextField } from '@material-ui/core';
import React, {Component} from 'react';
import { Link } from 'react-router-dom';
import Apiservice from '../Services/Apiservice';
import { DataContext } from './Context';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import { Alert } from '@material-ui/lab';


export default class Popup extends Component{

    constructor(){
        super();
        this.state={
          products:[],
          message:"",
          isSuccess:false,
          vertical : 'top',
      horizontal : 'center',
        }
        this.Addproduct = this.Addproduct.bind(this);
    }

    static contextType = DataContext;

    Addproduct=(e)=>{
        e.preventDefault()
        if(this.props.match.params.id){
        let products={
            id:this.state.id,
            name:this.state.name,
            quantity:this.state.quantity,
            price:this.state.price,
            img1:this.state.image1,
            cartegory:this.state.category,
            type:this.state.type,
            count:this.state.count
        }
        if(this.state.name && this.state.quantity && this.state.description && this.state.category 
          && this.state.price && this.state.image1 && this.state.count && this.state.type){
          Apiservice.updateProduct(products)
          .then((Response)=>{
            console.log("Hello")
            this.setState( {
              snackbaropen:true,
              isSuccess:true,
               message:'Successfull Update',
                products:Response.data.data
            })
            setTimeout(()=> this.fillAlert(), 3000)
         })
        }else{
          console.log("say hello")
          this.setState({snackbaropen:true, message:'Please fullfill the form !'})
          setTimeout(()=> this.fillAlert(), 4000)
    }
      
      // this.props.history.push("QD0tTak3Ap6r1")
      window.location.reload()
        }else{
          let products={
            id:this.state.id,
            name:this.state.name,
            quantity:this.state.quantity,
            price:this.state.price,
            img1:this.state.image1,
            cartegory:this.state.category,
            type:this.state.type,
            count:this.state.count
        }
        if(this.state.name && this.state.quantity && this.state.description && this.state.category 
          && this.state.price && this.state.image1 && this.state.count && this.state.type){
        Apiservice.retriveProduct(products)
        .then((Response)=>{
            console.log("HI buddy")
            this.setState( {
              snackbaropen:true,
              isSuccess:true,
               message:' Successfull Upload',
                products:Response.data
            })
        })
    }else{
      this.setState({snackbaropen:true, message:'Please fullfill the form !'})
      setTimeout(()=> this.fillAlert(), 4000)
    }
      // window.location.reload()

        }
          
  }
  fillAlert = () => {
    this.setState({snackbaropen:false})
    if(this.state.isSucess){
      this.props.history.push("/QD0tTak3Ap6r1");
    }
  }

    handleReset=()=>{
      this.setState({
        id:"",
        product:"",
        quantity:"",
        price:"",
        image1:"",
        category:"",
        type:"",
        count:"",
        description:""
      })
    }


     idChange = e => {
        this.setState({
          id:e.target.value
        })
      }

      nameChange=e=>{
        this.setState({
          product:e.target.value
        })
      }

      quantityChange=e=>{
        this.setState({
          quantity:e.target.value
        })
      }

      priceChange=e=>{
        this.setState({
          price:e.target.value
        })
      }

      image1Change=e=>{
        this.setState({
          image1:e.target.value
        })
      }

      categoryChange=e=>{
        this.setState({
          category:e.target.value
        })
      }

      typeChange=e=>{
        this.setState({
          type:e.target.value
        })
      }

      dateChange=e=>{
        this.setState({
          count:e.target.value
        })
      }

      descriptionChange=e=>{
        this.setState({
          description:e.target.value
        })
      }

         
    

    render(){
        // const{products}=this.state;

      //   const resetForm = () => {
      //     setValues(initialFValues);
      //     setErrors({})
      // }
      const { vertical, horizontal } = this.state;

        
        return(

            <>
            <Grid container style={{backgroundColor:"#e0f2f1"}}>
            {/* <Paper style={{width:300,height:20,color:"white",marginTop:150,backgroundColor:"red"}}><ErrorOutlineIcon/>{this.state.message}</Paper> */}
            <Snackbar open={this.state.snackbaropen} autoHideDuration={4000} anchorOrigin={{ vertical,horizontal }} key={vertical + horizontal} style={{marginTop:150, border:"solid",borderWidth:2,borderColor:"red",borderRadius:4}}>
              { this.state.isSucess ? (
                <Alert severity="success">
                  {this.state.message}
                </Alert>
              ):(
                <Alert severity="warning">
                {this.state.message}
              </Alert>
              )
              }
            </Snackbar>
                <Grid xs={3}/>
                <Grid xs={6}>
                    <Paper style={{boxShadow:20,marginTop:300,marginBottom:100}}>
              <form style={{width:1200,margin:20}}>
                    {/* onSubmit={handleSubmit} */}
                    <Grid container>
                      <Grid item xs={6} style={{paddingLeft:20}}>
                        <TextField
                          name="id"
                          label="Product id"
                          variant="standard"
                          value={this.state.id}
                          onChange={this.idChange}
                        /><br/>
                        <TextField
                          name="name"
                          label="Product Name"
                          variant="standard"
                          value={this.state.product}
                          onChange={this.nameChange}
                        /><br/>
                        <TextField
                          label="Quantity"
                          name="quantity"
                          variant="standard"
                          value={this.state.quantity}
                          onChange={this.quantityChange}
                        /><br/>
                        <TextField
                          label="Price"
                          name="price"
                          variant="standard"
                          value={this.state.price}
                          onChange={this.priceChange}
                        /><br/>
                         <TextField
                          label="Description"
                          name="description"
                          // label="Multiline Placeholder"
                          // placeholder="Placeholder"
                          multiline
                          variant="standard"
                          value={this.state.description}
                          onChange={this.descriptionChange}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <TextField
                          label="Image URL"
                          name="img1"
                          variant="standard"
                          value={this.state.image1}
                          onChange={this.image1Change}
                        /><br/>

                        <TextField
                          name="gender"
                          label="Category"
                          variant="standard"
                          value={this.state.category}
                          onChange={this.categoryChange}
                        //   items={genderId}
                        /><br/>
                        <TextField
                          name="departmentId"
                          label="Type"
                          variant="standard"
                          value={this.state.type}
                          onChange={this.typeChange}
                        //   options={productService.getDepartmentCollection()}
                        /><br/>
                        <TextField
                          name="count"
                          label="Count"
                          variant="standard"
                          value={this.state.count}
                          onChange={this.dateChange}
                        />

                        <div>
                          {/* <Link to="/QD0tTak3Ap6r1"> */}
                          <Button type="submit" text="ADD" href="/QD0tTak3Ap6r1"  onClick={this.Addproduct}  > ADD </Button>
                          {/* </Link> */}
                          <Button text="Reset" color="default"  onClick={this.handleReset} >RESET</Button>
                        </div>￼
                        {/* onClick={resetForm}  */}
                      </Grid>
                    </Grid>
                  </form>
                  </Paper>
                  </Grid>
                  <Grid xs={3}/>
                  </Grid>
                  </>
        )
    }
}
