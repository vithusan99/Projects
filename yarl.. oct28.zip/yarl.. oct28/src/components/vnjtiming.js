import React ,{Component} from 'react'





while(true){
    const time=new Date();
    const hour=time.getHours();
    if(hour===22){
        console.log("Good night");
        console.log("Sweet Dreams^^^^^ :) ");
        break;
    }else if(hour===6){
        console.log("Good Mornin g");
        console.log("Have a nice day   :) ");
        break;
    }else{
        console.log(" :( ")
    }
}

// by alapparai :):)