import React  from 'react';
import { DataContext } from './Context';



class TodoApp extends React.Component {
    constructor() {
      super();
      this.state = {
        // products: [],
        currentPage: 1,
        productsPerPage: 3
      };
      this.handleClick = this.handleClick.bind(this);
    }

    static contextType = DataContext;
  
    handleClick(event) {
      this.setState({
        currentPage: Number(event.target.id)
      });
    }
  
    render() {
      const {  currentPage, productsPerPage } = this.state;
      // const {products}=this.context;
  
      // Logic for displaying todos
      const indexOfLastProduct = currentPage * productsPerPage;
      const indexOfFirstProduct= indexOfLastProduct- productsPerPage;
      const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);
  
      const renderProducts = currentProducts.map((product, index) => {
        return <li key={index}>{product}</li>;
      });
  
      // Logic for displaying page numbers
      const pageNumbers = [];
      for (let i = 1; i <= Math.ceil(products.length / productsPerPage); i++) {
        pageNumbers.push(i);
      }
  
      const renderPageNumbers = pageNumbers.map(number => {
        return (
          <li
            key={number}
            id={number}
            onClick={this.handleClick}
          >
            {number}
          </li>
        );
      });
  
      return (
        <div>
          <ul>
            {renderProducts}
          </ul>
          <ul id="page-numbers">
            {renderPageNumbers}
          </ul>
        </div>
      );
    }
  }
  export default  TodoApp