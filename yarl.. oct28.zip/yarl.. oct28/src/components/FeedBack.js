import React, { useEffect } from "react";
import { Link } from 'react-router-dom';
import { makeStyles, Checkbox, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Grid,TextField,InputAdornment} from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import { useTheme } from '@material-ui/core/styles';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import { IconButton } from '@material-ui/core';
import ClearIcon from '@material-ui/icons/Clear';
import axios from 'axios';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
// import { useTheme } from '@material-ui/core/styles';
import { findAllByPlaceholderText } from "@testing-library/react";



const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
  grid: {
      margin:40,
      padding: '10px 10px 10px 10px',
      backgroundColor: "black"
  },
  paper: {
    padding: '10px 10px 10px 10px', 
    margin: '10px 10px 10px 10px',
    position: 'inherit'
  },
  search: {
    position: 'relative',
    align:'left',
    },
});

const useStyles1 = makeStyles((theme) => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props) {
  const classes = useStyles1();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = (event) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event) => {
    onChangePage(event, page - 1);
    console.log("Page" + page)
  };

  const handleNextButtonClick = (event) => {
    onChangePage(event, page + 1);
    console.log("Page" + page)
  };

  const handleLastPageButtonClick = (event) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}



export default function Feedback (props) {

  const classes = useStyles();
  const [Feedback, setFeedback] = React.useState([]);
  const [Message, setMesseage]= React.useState('');
  const [page, setPage] = React.useState(0);
  const [count, setCount] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  

  const deleteFeedback = (deleteId) => {
    axios.delete('http://localhost:8080/feedback/' + deleteId)
    .then((Response)=>{
      setMesseage('Feedback Deleted Successfully')
      setTimeout(()=>fillAlert(),3000)
    })
  }
  const fillAlert = () => {
    window.location.reload()
  }



    useEffect(() => {
      axios.get("http://localhost:8080/feedback/page")
        .then((Response) => {
        console.log(Response.data.Total_No_Of_Elements)
        setCount (Response.data.Total_No_Of_Elements)
        // console.log(count)
        setFeedback ( Response.data.data)
        // console.log(page)
        console.log(Feedback)
        //console.log(Response.data.data)
        
      })
      
    },[]);


   
  
    const handleChangeRowsPerPage = (event) => {
      setRowsPerPage(parseInt(event.target.value, 2));
      setPage(0);
    };

    const handleChangePage=(event,newPage)=>{
      setPage(newPage);
      {
        axios.get("http://localhost:8080/feedback/page?pageNo="+newPage)
        .then((Response) => {
          console.log(Response.data.Total_No_Of_Elements)
          setCount (Response.data.Total_No_Of_Elements)
          console.log(count)
          setFeedback ( Response.data.data)
      })
    }
  }

  
  return (
      <div style={{marginTop:150}}>
    <Grid className={classes.grid} style = {{backgroundColor:"#8c8c8c",marginTop:50}}>
      <Paper className = {classes.paper}>
        <h1>User FeedBack List </h1>
        <div className={classes.search}>
            <div className={classes.searchIcon} style = {{float: 'right'}}>

            </div>
        </div>
        <TableContainer>
      <Table className={classes.table} size="small">
        <TableHead>
          <TableRow>
            <TableCell align="left"><b>Action</b></TableCell>
            <TableCell align="left"><b>ID</b></TableCell>
            <TableCell align="left"><b>Feedback</b></TableCell>
            <TableCell align="left"><b>E-Mail</b></TableCell>
            <TableCell align="left"><b>Phone Num.</b></TableCell>
      
          </TableRow>
        </TableHead>
        <TableBody>
          {console.log(Feedback)}
          {Feedback.map((row) => (
            <TableRow>
              
              <TableCell>
              <IconButton
              // onClick={() => {if(window.confirm(location'Delete the item?')){deleteHistory(row.id)}}}
              onClick = {() => deleteFeedback(row.id)}
              // onClick = {() => window.location.reload()}
              >
              
              <DeleteIcon
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
              />
              </IconButton>


              <Link to={`/edit/${row.id}`}>
              {/* <IconButton 
              // onClick = {() => localStorageEditSave(row.id)}
              >
                <EditIcon
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
              />
              </IconButton> */}
              </Link>
              </TableCell>
              <TableCell align="left">{row.id}</TableCell>
              <TableCell align="left">{row.feedBack}</TableCell>
              <TableCell align="left">{row.eMail}</TableCell>
              <TableCell align="left">{row.phoneNum}</TableCell>
             
            </TableRow>
          ))}
          
        </TableBody>
        <TableFooter>
          <TableRow>
            <TablePagination
              rowsPerPageOptions={5}
              count={count}
              rowsPerPage={rowsPerPage}
              page={page}
              
           
              onChangePage={handleChangePage}
              onChangeRowsPerPage={handleChangeRowsPerPage}
              ActionsComponent={TablePaginationActions}
            />
            
          </TableRow>
        </TableFooter>
      </Table>
    </TableContainer>
      </Paper>
    </Grid>
    </div>
  );
}


////////////////////////////////////////////////////////////////////////
   
    // const localStorageEditSave = (updateId) => {
    //   localStorage.setItem('productId',updateId)
    //   console.log(updateId)
    //   props.history.push("/edit")
    // }
