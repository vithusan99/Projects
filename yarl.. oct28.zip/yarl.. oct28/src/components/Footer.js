
import './css/Footer.css'
import React, { Component } from 'react';
import FacebookIcon from '@material-ui/icons/Facebook';
import InstagramIcon from '@material-ui/icons/Instagram';
import WhatsAppIcon from '@material-ui/icons/WhatsApp';
import LinkedInIcon from '@material-ui/icons/LinkedIn';


class Footer extends Component {
  render() {

    if(this.props.data){
      var networks= this.props.data.social.map(function(network){
        return <li key={network.name}><a href={network.url}><i className={network.className}></i></a></li>
      })
    }

    return (
      <footer style={{position:"sticky"}}>

     <div className="row" style={{position:"sticky"}}>
        <div className="twelve columns">
           <ul className="social-links">
              <li> <FacebookIcon fontSize="large" /> </li>
              <li> <InstagramIcon fontSize="large" /> </li>
              <li> <WhatsAppIcon fontSize="large" /> </li>
              <li> <LinkedInIcon fontSize="large" /> </li>
           </ul>
           <ul className="copyright">
              <li>&copy; All credit goes to YarlMakket - Copyright 2020 YarlMakket</li>
              <li>Design by <a title="Styleshout" href="">YarlMakket</a></li>
           </ul>
           <ul>
             <img src="https://face-assets.dollarshaveclub.com/icons/app/payment-method-visa.svg?auto=format&fit=crop&h=24&w=36" />
             <img src="https://face-assets.dollarshaveclub.com/icons/app/payment-method-paypal.svg?auto=format&fit=crop&h=24&w=36" />
             <img src="https://face-assets.dollarshaveclub.com/icons/app/payment-method-amex.svg?auto=format&fit=crop&h=24&w=36" />

           </ul>

        </div>
        <div id="go-top"><a className="smoothscroll" title="Back to Top" href="#home"><i className="icon-up-open"></i></a></div>
     </div>
  </footer>
    );
  }
}

export default Footer;





////////////////////////////////////////////////////////
// import './css/Footer.css'
// import React, { Component } from 'react';
// import FacebookIcon from '@material-ui/icons/Facebook';
// import InstagramIcon from '@material-ui/icons/Instagram';
// import WhatsAppIcon from '@material-ui/icons/WhatsApp';
// import LinkedInIcon from '@material-ui/icons/LinkedIn';


// class Footer extends Component {
//   render() {

//     if(this.props.data){
//       var networks= this.props.data.social.map(function(network){
//         return <li key={network.name}><a href={network.url}><i className={network.className}></i></a></li>
//       })
//     }

//     return (
//       <footer style={{position:"sticky"}}>

//      <div className="row" style={{position:"sticky"}}>
//         <div className="twelve columns">
//            <ul className="social-links">
//               <li> <FacebookIcon fontSize="large" /> </li>
//               <li> <InstagramIcon fontSize="large" /> </li>
//               <li> <WhatsAppIcon fontSize="large" /> </li>
//               <li> <LinkedInIcon fontSize="large" /> </li>
//            </ul>
//            <ul className="copyright">
//            < hr style={{WebkitBoxShadow:"white",marginBottom:10,color:"#607d8b"}}/>
//               <li>&copy; All credit goes to YarlMakket - Copyright 2020 YarlMakket</li>
//               <li>Design by <a title="Styleshout" href="">YarlMakket</a></li>
//            </ul>

//         </div>
//         <div id="go-top"><a className="smoothscroll" title="Back to Top" href="#home"><i className="icon-up-open"></i></a></div>
//      </div>
//   </footer>
//     );
//   }
// }

// export default Footer;




// import React from 'react'
// import {Button, Box, makeStyles, AppBar,Toolbar, Grid } from '@material-ui/core';
// import CollectionsBookmarkOutlinedIcon from '@material-ui/icons/Collections'

// const new1Style=makeStyles({
// botbar:{
//     position:"relative",
//     backgroundColor:"#263238",
//     color:"white",
//     width:"100%",
//     height:300,
//     fontSize:20,
//     bottom:0,
//     left:0
// },
// lbot:{
//   color:"white",
//   textAlign:"center",
// },
// head:{
//   fontFamily:"Helvetica Neue",
//   fontSize:15,
//   top:400,
//   textAlign:"center",

// },
// tot:{
//   margin:0,
//   padding:0,
// }

// } );           


// function Footer(){

//   const classes= new1Style();
// return(

       
//                 <div className={classes.tot}>
//                 <Box className={classes.botbar}  >
//                 <Grid container>
//                   <Grid xs={3}  >
//                       <p>Contact Us</p>
//                       <p> Social media links :</p>
//                       <p> E-mail Address :</p>
//                   </Grid>
//                   <Grid xs={3}/>
//                   <Grid xs={3}><p>About Us :</p></Grid>
//                   </Grid>
//                   {/* <div className={classes.lbot} > */}
                    
//                     <h3 className={classes.head} >
//                     <hr style={{width:900,color:"white",margin:"auto",}}/>
//                     © 2020  YarlMakket. All Rights Reserved.
//                     <hr style={{width:700,color:"white",margin:"auto"}}/>
//                     </h3>
                    
//                   {/* </div> */}
//                 </Box>
//                  </div>
// )

// }
// export default Footer