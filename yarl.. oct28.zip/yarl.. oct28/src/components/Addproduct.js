
import { Button, Grid, Icon, IconButton, InputAdornment, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from '@material-ui/core';
import React, {Component} from 'react';
import SearchIcon from '@material-ui/icons/Search';
import { Link } from 'react-router-dom';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import ClearIcon from '@material-ui/icons/Clear';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import Apiservice from '../Services/Apiservice';
import { DataContext } from './Context';
import axios from 'axios';
// import add from 'fa fa-plus-circle';
import AddCircleIcon from '@material-ui/icons/AddCircle';

import Popup from './Popups';




const style={
    search:{

    }
}
export default class Addproduct extends Component{
    constructor(){
        super();
        this.state={
             products:[],
             currentPage: 1,
             productsPerPage: 5,
             searchString:"",
             searchChange:""
        };
        this.handleClick = this.handleClick.bind(this);


        // this.deleteProduct=this.deleteProduct.bind(this);

    }

    static contextType = DataContext;


    
    handleClick(event) {
      this.setState({
        currentPage: Number(event.target.id)
      });
    }

    searchChange = (e)=> {
      axios.get("http://localhost:8080/api/products?product="+e.target.value)
      .then ((response)=>{
          this.setState({products:response.data.data})
      }
          )
      this.setState({
          searchString:e.target.value
        })
}

     deleteProduct(id){
        Apiservice.deleteProduct(id)
            .then((Response)=>{
            console.log("HI")
            // setMesseage('Product Deleted Successfully')
            // setTimeout(()=>fillAlert(),3000)
            // this.setState( {
            //     products:Response.data
            // })
            // window.location.reload()
      })
    }

  //   clickHandler=(search)=>{
  //     axios.get("http://localhost:8080/api/products?product="+search)
  //     .then ((response)=>{
  //         this.setState({products:response.data})
  //     }
  //         )
      
  // }


    componentDidMount(){

        Apiservice.fetchProduct()
            .then((Response)=>{
            console.log("HI")
            this.setState( {
                products:Response.data
            })
      })
    

  
  }

   
    render(){
        // const { count, page, rowsPerPage, onChangePage } = this.props;
        const {products,setProducts}=this.state
        const {clickHandler} = this.context;
        const {  currentPage, productsPerPage } = this.state;

        const indexOfLastProduct = currentPage * productsPerPage;
        const indexOfFirstProduct= indexOfLastProduct- productsPerPage;
        const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);
  
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(products.length / productsPerPage); i++) {
          pageNumbers.push(i);
        }

        const renderPageNumbers = pageNumbers.map(number => {
          return (
            <li
              key={number}
              id={number}
              onClick={this.handleClick}
            >
              {number}
            </li>
          );
        });




        return(
            <>
            <Grid container >
                <Grid xs={2}/>
                <Grid xs={8}>
                    <Paper style={{borderRadius:10,backgroundColor:'#a7ffeb',marginTop:150}}>
      

         <div style={style.search}>
           <Grid container>
             <Grid xs={6}>
                                    <TextField
                            id="input-with-icon-textfield"
                            label="Search"
                            type="search"
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <IconButton onClick={()=> clickHandler(this.state.searchString)}  >
                                    <SearchIcon/>
                                  </IconButton>
                                </InputAdornment>
                              )}}
                            
                        />
                        </Grid>
                        <Grid xs={6}>
                        {/* <Link to="/addnew"> */}
                        <Button href="/QD0tTak3Ap6r1/addnew" style={{marginLeft:370,marginTop:20}}><AddCircleIcon/>ADD NEW PRODUCT</Button>
                        {/* </Link> */}
                        </Grid>
                        </Grid>
             </div>


             <TableContainer>
                 <Table style={{minWidth:650}}>
                         <TableHead>
                         <TableRow>
                            <TableCell align="left"><b>Action</b></TableCell>
                            <TableCell align="left"><b>ID</b></TableCell>
                            <TableCell align="left"><b>Product Name</b></TableCell>
                            <TableCell align="left"><b>Price</b></TableCell>
                            <TableCell align="left"><b>Quantity</b></TableCell>
                            <TableCell align="left"><b>Category</b></TableCell>
                            <TableCell align="left"><b>Type</b></TableCell>
                            <TableCell align="left"><b>Description</b></TableCell>
                         </TableRow>
                         </TableHead> 
                         <TableBody>
                             {/* {console.log(products)} */}
                         {currentProducts.map((row) => (
                                <TableRow>
                                
                                <TableCell>
                                
                                <IconButton
                                href="/QD0tTak3Ap6r1"
                                onClick = {() => this.deleteProduct(row.id)}
                                >
                                <DeleteIcon
                                    
                                    color="default"
                                    align="left"
                                    inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
                                />
                                </IconButton>


                                <Link to={`/QD0tTak3Ap6r1/addnew/${row.id}`}>
                                <IconButton 
                                href="/QD0tTak3Ap6r1/addnew/${row.id}"
                                // onClick = {() => EditSave(row.id)}
                                >
                                    <EditIcon
                                    color="default"
                                    align="left"
                                    inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
                                />
                                </IconButton>
                                </Link>
                                </TableCell>
                                <TableCell align="left">{row.id}</TableCell>
                                <TableCell align="left">{row.product}</TableCell>
                                <TableCell align="left">{row.price}</TableCell>
                                <TableCell align="left">{row.quantity}</TableCell>
                                <TableCell align="left">{row.category}</TableCell>
                                <TableCell align="left">{row.type}</TableCell>
                                <TableCell align="left">{row.description}</TableCell>
                                </TableRow>
                            ))}
                             </TableBody>  
                            
                 </Table>

             </TableContainer>
                            </Paper>
                            </Grid>
                            <Grid xs={2}/>
                            {renderPageNumbers}
                            </Grid>
                            {/* <Popup/> */}






        
        </>
        )
    }
}




//pagination

        // addNew=()=>{

        // }

        // const handleChangeRowsPerPage = (event) => {
        //     setRowsPerPage(parseInt(event.target.value, 10));
        //     setPage(0);
        //   };

        // const handleFirstPageButtonClick = (event) => {
        //   onChangePage(event, 0);
        // };
      
        // const handleBackButtonClick = (event) => {
        //   onChangePage(event, page - 1);
        //   console.log("Page" + page)
        // };
      
        // const handleNextButtonClick = (event) => {
        //   onChangePage(event, page + 1);
        //   console.log("Page" + page)
        // };
      
        // const handleLastPageButtonClick = (event) => {
        //   onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
        // };

        //buttons

              {/* <div className={classes.root}>
            <IconButton
              onClick={handleFirstPageButtonClick}
              disabled={page === 0}
              aria-label="first page"
            >
              {direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
            </IconButton>
            <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
              {direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
            </IconButton>
            <IconButton
              onClick={handleNextButtonClick}
              disabled={page >= Math.ceil(count / rowsPerPage) - 1}
              aria-label="next page"
            >
              {direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
            </IconButton>
            <IconButton
              onClick={handleLastPageButtonClick}
              disabled={page >= Math.ceil(count / rowsPerPage) - 1}
              aria-label="last page"
            >
              {direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
            </IconButton>
          </div> */}